
import java.util.*;


/* Student Name: Hadeel Alhosaini
 * Subject: SSW567
 * ID: 10395872
 */
public class HW1 {
	
	public static void main(String[] args){
		// Defining the program parameters
		        Scanner scan = new Scanner(System.in);
				String[] StringInput = new String[5];
				
        // Taking the name of the customer and printing them
			    for(int i=0; !scan.hasNext("exit"); i++){					  
				  for(int m=0; !scan.hasNext("exit") && m<=4; m++){
					  StringInput[m]=scan.next();
					  
					  if(m==4){
								
							for(int l=0; l<4; l++){
								StringInput[l]= StringInput[l]+ isIntegerAndPositive(StringInput[l])+"   ";			
							}
							StringInput[4]=isName(StringInput[4]);
							
							System.out.println(StringInput[0]+" "+StringInput[1]+" "+StringInput[2]+" "+StringInput[3]+" "+StringInput[4]+" ");
					  }						  
				  }
				  
				}
	
				scan.close();
		
		/*
		// Defining the program parameters
		int SwimLength, SwimWidth, SwimDepth1, SwimDepth2;
		String StringInput;
		String customer;
		Scanner scan = new Scanner(System.in);
		
		// Taking the name of the customer
		System.out.println("Program for calculating the time of preparing a swim pool");
		System.out.print("Please enter your name:   ");
		customer = scan.nextLine();
	
		// Taking the length of the customer's swimming pool
		System.out.print("Please enter your swimming pool length:   "); 
		StringInput = scan.nextLine();
		while (isIntegerAndPositive(StringInput) != true){
			System.out.print("Please enter your swimming pool length as a positive numeric value:   ");
			StringInput = scan.nextLine();
		}
		SwimLength = Integer.parseInt(StringInput);
		
		// Taking the width of the customer's swimming pool
		System.out.print("Please enter your swimming pool width:   ");
		StringInput = scan.nextLine();
		while (isIntegerAndPositive(StringInput) != true){
			System.out.print("Please enter your swimming pool width as a positive numeric value:   ");
			StringInput = scan.nextLine();
		}
		SwimWidth = Integer.parseInt(StringInput);
		
		// Taking the shallow end depth of the customer's swimming pool
		System.out.print("Please enter your swimming pool shallow end depth:   ");
		StringInput = scan.nextLine();
		while (isIntegerAndPositive(StringInput) != true){
			System.out.print("Please enter your swimming pool shallow end depth as a positive numeric value:   ");
			StringInput = scan.nextLine();
		}
		SwimDepth1 = Integer.parseInt(StringInput);
		
		// Taking the deep end depth of the customer's swimming pool
		System.out.print("Please enter your swimming pool deep end depth:   ");
		StringInput = scan.nextLine();
		while (isIntegerAndPositive(StringInput) != true){
			System.out.print("Please enter your swimming pool deep end depth as a positive numeric value:   ");
			StringInput = scan.nextLine();
		}
		SwimDepth2 = Integer.parseInt(StringInput);
		
		scan.close(); // Close the Scanner object
		
		// Printing the parameters in lines
		System.out.println();
		System.out.println("#############################");
		System.out.println("Your name is  " + customer);
		System.out.println("Your swimming pool length is  " + SwimLength + " feet");
		System.out.println("Your swimming pool width is  " + SwimWidth + " feet");
		System.out.println("Your swimming pool shallow end depth is  " + SwimDepth1 + " feet");
		System.out.println("Your swimming pool deep end depth is  " + SwimDepth2 + " feet");
		*/
			
	}
    
	// Method for checking string is a positive integer
	public static String isIntegerAndPositive(String value) {
	    /*int Intvalue;
		try { 
	        Intvalue = Integer.parseInt(value);
	    } catch(NumberFormatException e) { 
	        
	    	return " value isn't a number"; 
	    }
	    if(Intvalue < 0)
	    	return " value isn't a positive number";
	    return "";*/
		int Intvalue;
		try { 
	        Intvalue = Integer.parseInt(value);
	    } catch(NumberFormatException e) { 		        
	    	return " isn't a number"; 
	    }
	    if(Intvalue < 0)
	    	return " isn't a positive number";
	    return "";
	}
	
	// Method for checking string is a valid customer name
	 public static String isName(String value) {
			if(value.matches("[a-zA-Z]+"))
				return value;
			else return "\""+ value+ " isn't a valid name" + "\" ";
	    }
}



/*import javax.swing.*;
import java.awt.*;*/
/*
public static void main(String[] args){
	JFrame window1;
	window1 = new JFrame();
	window1.setLayout(new GridLayout(20,2));
	window1.setTitle("Calculate the time of preparing a swim pool");
	
	String SwimLength, SwimWidth, SwimDepth1, SwimDepth2;
	String customer;
	
	JLabel label1 = new JLabel("Please enter your name");
	window1.add(label1);
	JTextField input1 = new JTextField();
	customer = input1.getText();
	window1.add(input1);
	
	JLabel label2 = new JLabel("Please enter your swimming pool length");
	window1.add(label2);
	JTextField input2 = new JTextField(10);
	SwimLength =  input2.getText();
	window1.add(input2);
	
	JLabel label3 = new JLabel("Please enter your swimming pool width");
	window1.add(label3);
	JTextField input3 = new JTextField(10);
	SwimWidth =  input3.getText();
	window1.add(input3);
	
	JLabel label4 = new JLabel("Please enter your swimming pool shallow end depth");
	window1.add(label4);
	JTextField input4 = new JTextField(10);
	SwimDepth1 =  input4.getText();
	window1.add(input4);
	
	JLabel label5 = new JLabel("Please enter your swimming pool deep end depth");
	window1.add(label5);
	JTextField input5 = new JTextField(10);
	SwimDepth2 =  input5.getText();
	window1.add(input5);
	
	JButton OkButton = new JButton("Submit");
	OkButton.addActionListener(this);

	
	window1.setLocationRelativeTo(null);
	window1.setSize(500,600);
	window1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	window1.setVisible(true);
}*/

import static org.junit.Assert.*;

import org.junit.Test;


public class HW1Test {

	@Test
	public void testMain() {
		String[] input= {"34", "54", "-34", "e", "hadeel1"};
		
			
		for(int i=0; i<4; i++){
			input[i]= input[i]+ isIntegerAndPositive(input[i])+"   ";			
		}
		input[4]=isName(input[4]);
		
		System.out.println(input[0]+input[1]+input[2]+input[3]+input[4]);
	}
	    
	// Method for checking string is a positive integer
		public static String isIntegerAndPositive(String value) {
			int Intvalue;
			try { 
		        Intvalue = Integer.parseInt(value);
		    } catch(NumberFormatException e) { 		        
		    	return " isn't a number"; 
		    }
		    if(Intvalue < 0)
		    	return " isn't a positive number";
		    return "";
		}
		
    // Method for checking string is a valid customer name
		 public static String isName(String value) {
			if(value.matches("[a-zA-Z]+"))
				return value;
			else return "\""+ value+ " isn't a valid name" + "\" ";
		 }

}
